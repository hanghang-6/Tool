package com.nit.ssm.mapper;

import com.nit.ssm.dto.UserDTO;
import com.nit.ssm.entity.UserEntity;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository
public interface UserMapper {
    /**
     * @Description: 获取表格数据
     * @Author: SN
     * @Date: 2021/11/03 18:15
     */
    @Select({"SELECT " +
            "user_id, login_code, login_pwd, user_name, user_email, user_phone, user_type, gmt_create " +
            "FROM tb_user " +
            "WHERE login_code LIKE CONCAT('%', #{queryText}, '%') OR user_name LIKE CONCAT('%', #{queryText}, '%') " +
            "ORDER BY user_id desc " +
            "LIMIT #{start}, #{length}"})
    List<UserDTO> list4Table(@Param("start") Integer start,
                             @Param("length") Integer length,
                             @Param("queryText") String queryText) throws Exception;

    /**
     * @Description: 获取表格数据记录的总条数
     * @Author: SN
     * @Date: 2021/11/03 18:15
     */
    @Select({"<script>SELECT COUNT(*) " +
            "FROM tb_user " +
            "WHERE login_code LIKE CONCAT('%', #{queryText}, '%') OR user_name LIKE CONCAT('%', #{queryText}, '%')</script>"})
    Integer count4Table(@Param("queryText") String queryText) throws Exception;

    /**
     * @Description: 添加记录
     * @Author: SN
     * @Date: 2021/11/03 18:15
     */
    @Insert("INSERT INTO tb_user ( " +
            "login_code, login_pwd, user_name, " +
            "user_email, user_phone, " +
            "user_type, gmt_create) " +
            "VALUES (#{userEntity.loginCode}, #{userEntity.loginPwd}, #{userEntity.userName}, " +
            "#{userEntity.userEmail}, #{userEntity.userPhone}, " +
            "#{userEntity.userType}, #{userEntity.gmtCreate})")
    @Options(useGeneratedKeys = true, keyProperty = "userId", keyColumn = "user_id")
    Integer add(@Param("userEntity") UserEntity userEntity) throws Exception;

    /**
     * @Description: 编辑记录
     * @Author: SN
     * @Date: 2021/11/03 18:15
     */
    @Update("UPDATE tb_user " +
            "SET user_name = #{userEntity.userName}, " +
            "user_email = #{userEntity.userEmail}, " +
            "user_phone = #{userEntity.userPhone} " +
            "WHERE user_id = #{userEntity.userId}")
    Integer edit(@Param("userEntity") UserEntity userEntity) throws Exception;


    /**
     * @Description: 删除记录
     * @Author: SN
     * @Date: 2021/11/03 18:15
     */
    @Delete({"DELETE FROM tb_user WHERE user_id = #{userId}"})
    Integer remove(@Param("userId") Integer userId) throws Exception;

}
