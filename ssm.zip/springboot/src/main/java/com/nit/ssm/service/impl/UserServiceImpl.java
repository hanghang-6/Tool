package com.nit.ssm.service.impl;

import com.nit.ssm.dto.UserDTO;
import com.nit.ssm.dto.TableReqDTO;
import com.nit.ssm.dto.TableRspDTO;
import com.nit.ssm.entity.UserEntity;
import com.nit.ssm.mapper.UserMapper;
import com.nit.ssm.service.UserService;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

@Service
public class UserServiceImpl implements UserService {

    private final UserMapper userMapper;

    @Autowired
    public UserServiceImpl(UserMapper userMapper) {
        this.userMapper = userMapper;
    }

    @Override
    public TableRspDTO list4Table(TableReqDTO tableReqDTO) throws Exception {
        Integer count = userMapper.count4Table(tableReqDTO.getQueryText());
        List<UserDTO> listUserDTOs = userMapper.list4Table(tableReqDTO.getStart(),
                tableReqDTO.getPageSize(), tableReqDTO.getQueryText());
        return new TableRspDTO(count, listUserDTOs);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Integer add(UserDTO userDTO) throws Exception {
        MapperFactory mapperFactory = new DefaultMapperFactory.Builder().build();
        UserEntity userEntity = mapperFactory.getMapperFacade().map(userDTO, UserEntity.class);
        userEntity.setUserType("2");
        userEntity.setGmtCreate(new Date());
        return userMapper.add(userEntity);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Integer edit(UserDTO userDTO) throws Exception {
        MapperFactory mapperFactory = new DefaultMapperFactory.Builder().build();
        UserEntity userEntity = mapperFactory.getMapperFacade().map(userDTO, UserEntity.class);
        return userMapper.edit(userEntity);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Integer remove(Integer userId) throws Exception {
        return userMapper.remove(userId);
    }
}
